#include "main.h"
#include "okapi/api.hpp"

#pragma
// ports for motor

// chassis motors
const int LEFT_MTR1 = 1;
const int LEFT_MTR2 = 2;
const int RIGHT_MTR1 = 3;
const int RIGHT_MTR2 = 4;

// lift and clamp motors
const int CLAMP_MTR = 5;
const int LIFT_MTR = 6;
const int LIFT_MTR2 = 7;

//intake motor
const int Intate_MTR1 = 8;

// sensors
