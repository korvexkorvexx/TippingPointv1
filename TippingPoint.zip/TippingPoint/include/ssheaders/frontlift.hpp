#include "main.h"

//Helper Function
void setMogowing(int power);

//Driver Function
void setMogowingMotor();
