#include "main.h"

//Helper Function
void setLift(int power);

//Driver Function
void setLiftMotors();
