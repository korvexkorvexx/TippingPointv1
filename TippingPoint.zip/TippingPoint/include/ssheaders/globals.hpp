#include "main.h"

extern pros::Motor lift1;
extern pros::Motor lift2;
extern pros::Motor intake;
extern pros::Motor lift3;
extern pros::Motor chassisLB;
extern pros::Motor chassisLF;
extern pros::Motor chassisRB;
extern pros::Motor chassisRF;

extern pros::Controller controller;
extern pros::ADIDigitalOut piston;
extern pros::ADIGyro gyro;
