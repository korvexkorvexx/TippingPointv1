#include "main.h"

void setDrive(int left, int right);

void setDriveMotors();
