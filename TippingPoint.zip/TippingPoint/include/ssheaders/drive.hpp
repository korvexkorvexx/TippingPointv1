#include "main.h"

//Helper Functions
void setDrive(int left, int right);

void resetDriveEncoders();

double avgDriveEncoderValue();

//Drive Functions
void setDriveMotors();

//Auton Functions
void translate(int units, int voltage);

void rotate(int degrees, int voltage);
