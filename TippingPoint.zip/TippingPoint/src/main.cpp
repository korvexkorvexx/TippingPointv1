#include "main.h"


void opcontrol() {
  while(true) {
    setDriveMotors();
    setMogowingMotor();
    setLiftMotors();
    setClampPiston();
    pros::delay(10);
  }
}
