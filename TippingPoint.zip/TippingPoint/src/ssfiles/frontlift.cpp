#include "main.h"

//Helper Function
void setMogowing(int power)
{
  lift3 = power;
}

//Driver Function
void setMogowingMotor()
{
  int mogowingPower = 127 * (controller.get_digital(pros::E_CONTROLLER_DIGITAL_R1) - controller.get_digital(pros::E_CONTROLLER_DIGITAL_R2));
  setMogowing(mogowingPower);
}
