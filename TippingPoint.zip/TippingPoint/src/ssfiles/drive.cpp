#include "main.h"

void setDrive(int left, int right) {
  chassisLB = left;
  chassisLF = left;
  chassisRB = right;
  chassisRF = right;
}

void setDriveMotors() {
  int leftJoystick = controller.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
  int rightJoystick = controller.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_Y);
  setDrive(leftJoystick, rightJoystick);
}
