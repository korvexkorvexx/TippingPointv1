#include "main.h"

pros::ADIGyro gyro('B', 1);

//Helper Functions
void setDrive(int left, int right)
{
  chassisLB = left;
  chassisLF = left;
  chassisRB = -right;
  chassisRF = -right;
}

void resetDriveEncoders()
{
  chassisLB.tare_position();
  chassisRB.tare_position();
  chassisRF.tare_position();
  chassisLF.tare_position();
}

double avgchassisEncoderValue()
{
  return (fabs(chassisLF.get_position()) + fabs(chassisRF.get_position()) + fabs(chassisLB.get_position()) + fabs(chassisRB.get_position()))/4;
}

//chassis Functions
void setDriveMotors()
{
  int leftJoystick = controller.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
  int rightJoystick = controller.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_Y);
  if(abs(leftJoystick) < 10)
    leftJoystick = 0;
  if(abs(rightJoystick) < 10)
    rightJoystick = 0;
  setDrive(leftJoystick, rightJoystick);
}

//Auton Functions
void translate(int units, int voltage)
{
  int direction = abs(units)/units;
  resetDriveEncoders();
  gyro.reset();
  while(avgchassisEncoderValue() < abs(units))
  {
    setDrive(voltage * direction + gyro.get_value(), voltage * direction - gyro.get_value());
    pros::delay(10);
  }
  setDrive(-10 * direction, -10 * direction);
  pros::delay(50);
  setDrive(0,0);
}

void rotate(int degrees, int voltage)
{
  int direction = abs(degrees)/degrees;
  gyro.reset();
  setDrive(-voltage * direction, voltage * direction);
  while(fabs(gyro.get_value()) < abs(degrees * 10) - 50)
  {
    pros::delay(10);
  }
  pros::delay(100);
  if(fabs(gyro.get_value()) > abs(degrees * 10))
  {
    setDrive(0.5 * voltage * direction, 0.5 * -voltage * direction);
    while(fabs(gyro.get_value()) > abs(degrees * 10))
    {
      pros::delay(10);
    }
  }
  else if(fabs(gyro.get_value()) < abs(degrees * 10))
  {
    setDrive(0.5 * -voltage * direction, 0.5 * voltage * direction);
    while(fabs(gyro.get_value()) < abs(degrees * 10))
    {
      pros::delay(10);
    }
  }
  setDrive(0,0);
}
