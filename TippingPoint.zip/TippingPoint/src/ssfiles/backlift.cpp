#include "main.h"

//Helper Function
void setLift(int power)
{
  lift1.move_velocity(power);
  lift2.move_velocity(-power);
}

//Driver Function
void setLiftMotors()
{
  int counter = 0;
  if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_L1) && counter != 1) {
    setLift(2000);
    pros::delay(1200);
    setLift(0);
    lift1.set_brake_mode(MOTOR_BRAKE_HOLD);
    lift2.set_brake_mode(MOTOR_BRAKE_HOLD);
    counter++;
  } else if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_L2) && counter != -1) {
    setLift(-2000);
    pros::delay(1200);
    setLift(0);
    lift2.set_brake_mode(MOTOR_BRAKE_HOLD);
    lift1.set_brake_mode(MOTOR_BRAKE_HOLD);
    counter--;
  }

}
