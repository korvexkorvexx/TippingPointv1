#include "main.h"


#define DIGITAL_SENSOR_PORT 'A'

void pneumaticMove(bool pressure) {
  piston.set_value(pressure);
}

//Drive Function
int counter = 0;
void setClampPiston() {
  if(controller.get_digital(pros::E_CONTROLLER_DIGITAL_UP)) {
     counter++;
     //pros::delay(1);
  }
  if(counter%2 == 1) {
    pneumaticMove(true);
  } else if(counter%2 == 0) {
    pneumaticMove(false);
  }

}
